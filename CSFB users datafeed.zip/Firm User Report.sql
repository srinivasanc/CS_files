CREATE PROCEDURE [dbo].[RPT_CSFB_EXP_FIRM_JOBS_COMPLETED]
	@FROMDATE	DATETIME	,
	@USER		NVARCHAR(50),
	@URL		NVARCHAR(255)
AS
BEGIN
	/*
		Name 		:	RPT_CSFB_EXP_FIRM_JOBS_COMPLETED
		Description	:	Produces data for completed jobs report for firm user
		Written On	:   10/16/2013 By Srinivasan
	*/
    
    --Do we have a startdate
    IF @FROMDATE IS NULL
	BEGIN
		RAISERROR ('STARTING DATE IS REQUIRED', 16, 1)
		RETURN
    END

    --Do we have a user
    IF @USER IS NULL
    BEGIN
		RAISERROR ('USER IS REQUIRED', 16, 1)
		RETURN
    END 
    
    DECLARE @TODATE DATETIME 
    IF DAY(@FROMDATE) = 1 -- If it's the first of the month go to the end, else return 30 days
		SET @TODATE = DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, @FROMDATE) + 1, 0))
	ELSE 
		SET @TODATE = @FROMDATE + 30
	
	SELECT	[Job#]						=	JOB_NO + '-' + JOB_SUB_NO,
			[Due Date]					=	DUE_DATE,
			[Banker Name]				=	ACCT_EXEC,
			[Requested Date]			=	REQUESTED_DATE,
			[Report Title]				=	job_title,
			[Project Code]				=	Alt01,
			[Client Code]				=	eml06
	FROM	VWJOBTICKETS WITH(NOLOCK)
	WHERE	COMPLETED BETWEEN @FROMDATE AND @TODATE AND [STATUS]='COMPLETED' 
			AND TIMEKEEPER IN (SELECT TIMEKEEPER FROM USERS WITH(NOLOCK) WHERE [USER] = @USER)
	ORDER BY [SITE], [Job#]
	
 
END


GO
